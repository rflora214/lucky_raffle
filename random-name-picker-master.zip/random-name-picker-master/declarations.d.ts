declare global {
  interface Window {
    webkitAudioContext: AudioContext;
  }
}

export {};
